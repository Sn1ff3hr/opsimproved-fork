#!/usr/bin/env python3
"""Audit HTML files for broken or suspicious links within the repo."""
from __future__ import annotations

import json

import sys
from dataclasses import dataclass, asdict
from html.parser import HTMLParser
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple
from urllib.parse import urldefrag, urlparse

REPO_ROOT = Path(__file__).resolve().parents[1]

SKIP_DIRS = {"node_modules", ".git"}
HTML_EXTENSIONS = {".html", ".htm"}

LinkPos = Tuple[int, int]

@dataclass
class LinkRecord:
    file: str
    tag: str
    attr: str
    value: str
    position: LinkPos
    status: str
    detail: Optional[str] = None


class LinkCollector(HTMLParser):
    """Collect href/src-like attributes and id targets from HTML."""

    LINK_ATTRS = {
        "a": ("href",),
        "link": ("href",),
        "script": ("src",),
        "img": ("src", "srcset"),
        "source": ("src", "srcset"),
        "iframe": ("src",),
        "audio": ("src",),
        "video": ("src",),
        "track": ("src",),
        "form": ("action",),
        "use": ("href",),
    }

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.ids: set[str] = set()
        self.links: List[Tuple[str, str, str, LinkPos]] = []

    def handle_starttag(self, tag: str, attrs: Sequence[Tuple[str, Optional[str]]]) -> None:
        attr_map = dict(attrs)
        element_id = attr_map.get("id")
        if element_id:
            self.ids.add(element_id)
        for attr in self.LINK_ATTRS.get(tag, ()):  # type: ignore[arg-type]
            value = attr_map.get(attr)
            if value:
                self.links.append((tag, attr, value, self.getpos()))


def iter_html_files(root: Path) -> List[Path]:
    files: List[Path] = []
    for path in root.rglob("*.html"):
        if any(part in SKIP_DIRS for part in path.parts):
            continue
        files.append(path)
    return files


def classify_url(url: str) -> str:
    if not url:
        return "empty"
    url = url.strip()
    if url.startswith("data:"):
        return "data"
    if url.startswith("javascript:"):
        return "javascript"
    if url.startswith("mailto:"):
        return "mailto"
    if url.startswith("tel:"):
        return "tel"
    if url.startswith("//"):
        return "external"
    parsed = urlparse(url)
    if parsed.scheme and parsed.scheme not in {"http", "https"}:
        return parsed.scheme
    if parsed.scheme in {"http", "https"}:
        return "external"
    return "local"


def audit_links(html_files: Sequence[Path]) -> Tuple[List[LinkRecord], Dict[str, List[str]]]:
    file_ids: Dict[Path, set[str]] = {}
    file_links: Dict[Path, List[Tuple[str, str, str, LinkPos]]] = {}
    for html in html_files:
        collector = LinkCollector()
        try:
            collector.feed(html.read_text(encoding="utf-8"))
        except Exception as exc:  # pragma: no cover - defensive
            raise RuntimeError(f"Failed to parse {html}: {exc}") from exc
        file_ids[html] = collector.ids
        file_links[html] = collector.links

    records: List[LinkRecord] = []
    unresolved_ids: Dict[str, List[str]] = {}

    for html, links in file_links.items():
        for tag, attr, value, position in links:
            url_type = classify_url(value)
            status = "ok"
            detail: Optional[str] = None

            if url_type == "local":
                # Strip fragments and query for file existence
                clean_url, fragment = urldefrag(value)
                parsed = urlparse(clean_url)
                target_path = parsed.path
                if not target_path:
                    # Pure fragment reference within same file
                    if fragment and fragment not in file_ids[html]:
                        status = "missing-id"
                        detail = f"Fragment '#{fragment}' not found in document"
                else:
                    candidate = (REPO_ROOT / target_path.lstrip("/") if target_path.startswith("/")
                                 else (html.parent / target_path)).resolve()
                    if not candidate.exists():
                        status = "missing"
                        detail = f"Path '{target_path}' not found"
                    else:
                        if fragment:
                            target_ids = file_ids.get(candidate)
                            if target_ids is None and candidate.suffix in HTML_EXTENSIONS:
                                # Parse lazily if needed
                                collector = LinkCollector()
                                collector.feed(candidate.read_text(encoding="utf-8"))
                                target_ids = collector.ids
                                file_ids[candidate] = collector.ids
                                file_links.setdefault(candidate, collector.links)
                            if fragment and target_ids is not None and fragment not in target_ids:
                                status = "missing-id"
                                detail = f"Fragment '#{fragment}' not found in {candidate.relative_to(REPO_ROOT)}"
            elif url_type in {"empty", "javascript"}:
                status = "skipped"
                detail = f"Ignored {url_type} URL"
            elif url_type in {"mailto", "tel", "data"}:
                status = "informational"
                detail = f"{url_type} link"
            else:
                status = "external"

            records.append(
                LinkRecord(
                    file=str(html.relative_to(REPO_ROOT)),
                    tag=tag,
                    attr=attr,
                    value=value,
                    position=position,
                    status=status,
                    detail=detail,
                )
            )

    for html, ids in file_ids.items():
        if not ids:
            continue
        unresolved_ids[str(html.relative_to(REPO_ROOT))] = sorted(ids)

    return records, unresolved_ids


def main(argv: Sequence[str]) -> int:
    html_files = iter_html_files(REPO_ROOT)
    records, _ = audit_links(html_files)
    output = {
        "records": [asdict(record) for record in records],
    }
    json.dump(output, sys.stdout, indent=2)
    sys.stdout.write("\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
