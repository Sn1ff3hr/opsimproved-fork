# Link and Honeypot Audit

## Methodology
- Parsed every HTML fragment and page in the repository with `scripts/link_audit.py`,
  which records each `href`/`src` target, classifies it (local vs. external), and
  verifies that local resources and fragment IDs resolve within the repo.【F:scripts/link_audit.py†L1-L172】
- Captured the raw results in `link_audit.json` for traceability and generated a per-page
  roll-up of statuses from that dataset.【F:link_audit.json†L1-L60】【38e11d†L1-L16】
- Manually probed the remote endpoints used by forms, assets, and honeypot reporting to
  confirm whether they respond from the current environment.【de91a0†L1-L10】【96a90d†L1-L8】【207e2c†L1-L8】【b0dd6f†L1-L8】【a1dbac†L1-L8】

## Link Health Summary
| Page | Total links | Local OK | External (network required) | Notes |
| --- | --- | --- | --- | --- |
| `index.html` | 24 | 22 | 2 | Navigation links resolve internally; DOMPurify CDN and Font Awesome require internet access (403 via container proxy).【F:link_audit.json†L1-L60】【de91a0†L1-L10】【96a90d†L1-L8】【F:index.html†L33-L114】 |
| `contact-center.html` | 24 | 22 | 2 | All in-repo assets present; same CDN dependencies as index.【F:link_audit.json†L1-L60】 |
| `it-support.html` | 24 | 22 | 2 | Internal anchors resolve; external scripts blocked by current proxy.【F:link_audit.json†L1-L60】【96a90d†L1-L8】 |
| `professional-services.html` | 25 | 22 | 3 | Partner placeholder image and CDN scripts blocked without internet.【F:link_audit.json†L1-L60】【207e2c†L1-L8】 |

_No missing local files or fragment IDs were detected by the crawler._

## Honeypot Coverage
- The shared antibot helper preloads `security/honeypots.html` and injects honeypot
  inputs into forms and the chatbot when templates are available, falling back to a
  generated hidden field if the template cannot be fetched.【F:js/antibot.js†L1-L105】【F:security/honeypots.html†L1-L13】
- Modal fragments for the contact and join workflows already include hidden honeypot
  inputs, so bots must trip them even if the templates fail to load.【F:fabs/contact.html†L1-L59】【F:fabs/join.html†L1-L126】
- The chatbot loader adds both honeypot fields and reports tampering to a worker endpoint
  before locking the UI, mirroring the form protections.【F:fabs/js/chattia.js†L1-L115】

## Remote Endpoint Observations
- Contact and join submissions POST to dedicated Cloudflare Workers; the domains resolve
  but returned HTTP 403 through the sandbox proxy, so functional testing requires an
  environment with outbound access or mocked endpoints.【F:fabs/js/cojoin.js†L13-L150】【b0dd6f†L1-L8】【a1dbac†L1-L8】
- The chatbot defaults to `https://your-cloudflare-worker.opsonlinesupport.com`, a
  placeholder that must be overridden in production to reach a real worker; otherwise,
  it will fail once it tries to fetch `/chat` or `/honeypot-trip`.【F:fabs/js/chattia.js†L1-L115】
- CDN assets (Font Awesome and DOMPurify) and the placeholder logo image require outbound
  HTTP(S); they respond with 403 via this container’s egress proxy but are expected to
  work in a normal runtime with public internet access.【de91a0†L1-L10】【96a90d†L1-L8】【207e2c†L1-L8】

## Recommendations
1. Keep `link_audit.json` under version control so future diffs surface new missing assets.
2. Consider bundling critical third-party scripts locally or via subresource integrity to
   reduce runtime dependency on CDNs.
3. Add environment-specific overrides for the worker endpoints during local QA to avoid
   false negatives when the sandbox blocks outbound calls.
