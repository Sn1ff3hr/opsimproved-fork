# Cookie Consent Notice

## Purpose of Cookies
We use essential and performance cookies to deliver, secure, and optimize our digital services. These cookies help us:

- Maintain platform stability and security (e.g., session integrity, fraud prevention).
- Measure anonymized behavioral interactions to improve usability, accessibility, and content relevance.
- Ensure compliance with regulatory, cybersecurity, and accessibility obligations.

No personal information beyond anonymized behavioral signals (such as page views, clicks, or device type) is collected or stored via cookies. We do not collect names, email addresses, payment details, or any directly identifiable data through cookies.

## Types of Cookies
| Cookie Type | Description | Retention |
| --- | --- | --- |
| **Strictly Necessary** | Required to provide secure access, load balancing, and user-requested functionality. | Session-based or up to 12 months. |
| **Performance & Analytics** | Aggregated insights on navigation flows, feature usage, and Core Web Vitals to improve UX and resilience. | 13 months maximum. |

We do not deploy marketing, profiling, or third-party advertising cookies.

## Consent Management
- On first visit, users are presented with a banner explaining our cookie usage and providing a link to this notice.
- Essential cookies are always active; performance cookies activate only after explicit user consent.
- Users can manage or withdraw consent at any time via in-app controls or by adjusting browser settings.

## Data Governance & Security
- Behavioral analytics are pseudonymized and aggregated to prevent re-identification.
- Data is protected via TLS 1.2+ in transit, AES-256 at rest, and access is restricted under least-privilege policies.
- Logs supporting incident response are retained for no longer than necessary to fulfill security obligations.

## Contact & Feedback
For questions about this Cookie Consent Notice or to request assistance with consent choices, please contact our Privacy Office at privacy@yourdomain.com.

_Last updated: 2024-06-07_
