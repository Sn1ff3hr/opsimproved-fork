# Privacy Notice & Terms of Use

_Last updated: 2024-06-07_

## 1. Overview
We design privacy-first experiences that comply with global digital regulations, including GDPR, CCPA, NIST CSF, CISA Cyber Essentials, and PCI DSS controls applicable to behavioral telemetry. This document explains how we collect and use data and the conditions governing access to our services.

## 2. Scope
This notice applies to all visitors and users of our digital properties, including web, mobile, and connected experiences managed under the yourdomain.com brand and its subdomains.

## 3. Data Collection & Use
- **Behavioral Signals Only.** We collect aggregated behavioral analytics (page views, device/browser metadata, performance metrics, clickstream navigation) to improve security, accessibility, and user experience.
- **No Direct Personal Data.** We do not collect names, emails, billing details, or other personally identifiable information unless a user intentionally provides such details through separate, clearly labeled workflows.
- **Processing Purposes.** Behavioral data is used for UX optimization, resilience monitoring, anomaly detection, and compliance reporting.
- **Legal Bases.** Processing is grounded in legitimate interest for service improvement and security, combined with explicit user consent where required for non-essential analytics.

## 4. Data Sharing & Disclosure
- We do not sell or rent information. Behavioral telemetry may be processed by vetted processors providing analytics, security monitoring, or hosting. Each processor is bound by data processing agreements, least-privilege access, and regulatory obligations.
- Data may be disclosed if required by law, to respond to lawful requests, or to protect the rights, safety, and integrity of users, partners, or the platform.

## 5. Retention & Security
- Behavioral logs are retained only as long as needed to achieve the purposes above, generally no longer than 13 months.
- Data in transit is protected with TLS 1.2+; data at rest uses AES-256 encryption.
- Security monitoring integrates SIEM, anomaly detection, and incident response aligned with NIST CSF and OPS CyberSec Core controls.

## 6. International Data Transfers
Data may be transferred across regions where we or our processors operate. We maintain standard contractual clauses or equivalent safeguards for cross-border transfers.

## 7. User Rights & Controls
- Users can opt out of non-essential analytics at any time via cookie controls or by contacting privacy@yourdomain.com.
- Users may request confirmation that no directly identifiable personal data is stored by emailing privacy@yourdomain.com. Responses are provided within 30 days.

## 8. Children's Data
Our services are not directed to children under 16, and we do not knowingly collect behavioral or personal data from minors. If we learn that a minor has provided personal data, we will delete it promptly.

## 9. Updates to this Notice
Material updates will be communicated through in-app notifications or banner alerts. Continued use of the services after updates indicates acceptance of the revised notice.

---

# Terms & Conditions

## 1. Acceptance of Terms
By accessing or using our services, you agree to be bound by these Terms & Conditions ("Terms"). If you do not agree, discontinue use immediately.

## 2. Eligibility
You must be at least 16 years old and capable of entering a binding contract. Use of the services constitutes representation that you meet these requirements.

## 3. Permitted Use
- Use the services only for lawful purposes and in accordance with these Terms.
- Do not attempt unauthorized access, reverse engineering, scraping, or interference with security controls, uptime, or infrastructure.
- Respect intellectual property rights and follow all applicable laws.

## 4. Account Responsibilities
If you interact with authenticated features, you are responsible for maintaining the confidentiality of credentials and for all activities under your account. Notify us immediately of unauthorized access or suspected breaches.

## 5. Intellectual Property
All content, trademarks, and technology within the services are owned by or licensed to yourdomain.com. Limited, non-transferable, revocable access is granted for personal or internal business use. No rights are granted to copy, modify, distribute, or create derivative works without written permission.

## 6. Availability & Maintenance
We strive for continuous availability but do not guarantee uninterrupted service. Maintenance, updates, or force majeure events may temporarily impact access. We are not liable for outages beyond our reasonable control.

## 7. Third-Party Links
Our services may include links to third-party sites. We do not control or endorse third-party content and are not responsible for their privacy practices or terms.

## 8. Disclaimers
Services are provided "as is" and "as available." To the fullest extent permitted by law, we disclaim all warranties, express or implied, including merchantability, fitness for a particular purpose, and non-infringement.

## 9. Limitation of Liability
To the maximum extent allowed, yourdomain.com and its affiliates are not liable for indirect, incidental, consequential, or punitive damages arising from use of the services. Aggregate liability shall not exceed USD 100 or the amount paid by you to use the services in the 12 months preceding the claim, whichever is greater.

## 10. Indemnification
You agree to indemnify and hold harmless yourdomain.com, its officers, employees, and partners from any claims arising out of your use of the services, violation of these Terms, or infringement of third-party rights.

## 11. Governing Law & Jurisdiction
These Terms are governed by the laws of the jurisdiction where yourdomain.com is incorporated, without regard to conflict-of-law rules. Any disputes will be resolved in the competent courts of that jurisdiction.

## 12. Changes to Terms
We may update these Terms from time to time. Continued use after changes indicates acceptance. Material changes will be communicated via service announcements or email.

## 13. Contact
For questions about these Terms, contact legal@yourdomain.com.
