document.addEventListener('DOMContentLoaded', () => {
  const searchButton = document.getElementById('search-button');
  const voiceSearchButton = document.getElementById('voice-search-button');
  const searchInput = document.getElementById('search-input');
  const searchResultsContainer = document.getElementById('search-results');

  // If the required elements are not present, exit early to avoid errors
  if (!searchButton || !searchInput || !searchResultsContainer) {
    return;
  }

  const voiceStatus = document.createElement('p');
  voiceStatus.id = 'voice-search-status';
  voiceStatus.className = 'voice-search-status';
  voiceStatus.setAttribute('role', 'status');
  voiceStatus.setAttribute('aria-live', 'polite');
  voiceStatus.hidden = true;
  searchResultsContainer.insertAdjacentElement('beforebegin', voiceStatus);

  const setVoiceStatus = (message, { persist = false } = {}) => {
    if (!voiceStatus) return;

    window.clearTimeout(setVoiceStatus.timeoutId);

    if (!message) {
      voiceStatus.hidden = true;
      if (!persist) {
        voiceStatus.textContent = '';
      }
      return;
    }

    voiceStatus.hidden = false;
    voiceStatus.textContent = message;

    if (!persist) {
      setVoiceStatus.timeoutId = window.setTimeout(() => {
        voiceStatus.hidden = true;
        voiceStatus.textContent = '';
      }, 4000);
    }
  };

  let searchIndex = [];
  let bm25Docs = [];
  let docFrequency = new Map();
  let averageDocLength = 0;
  const k1 = 1.5;
  const b = 0.75;

  const tokenize = (text = '') => {
    return (text.toLowerCase().match(/[a-z0-9]+/g) || []).filter(Boolean);
  };

  const slugify = (value = '') => {
    return value
      .toLowerCase()
      .replace(/\.html?$/, '')
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '');
  };

  const buildBm25Index = () => {
    if (!Array.isArray(searchIndex) || searchIndex.length === 0) {
      bm25Docs = [];
      docFrequency = new Map();
      averageDocLength = 0;
      return;
    }

    bm25Docs = searchIndex.map(page => {
      const tokens = tokenize(page.content);
      const termFrequency = tokens.reduce((map, token) => {
        map.set(token, (map.get(token) || 0) + 1);
        return map;
      }, new Map());

      return {
        ...page,
        tokens,
        termFrequency,
        length: tokens.length
      };
    });

    const totalLength = bm25Docs.reduce((sum, doc) => sum + doc.length, 0);
    averageDocLength = bm25Docs.length ? (totalLength / bm25Docs.length) : 0;

    docFrequency = new Map();
    bm25Docs.forEach(doc => {
      const uniqueTokens = new Set(doc.tokens);
      uniqueTokens.forEach(token => {
        docFrequency.set(token, (docFrequency.get(token) || 0) + 1);
      });
    });
  };

  const loadIndex = async () => {
    try {
      const res = await fetch('js/search-index.json');
      if (!res.ok) throw new Error('Failed to load search index');
      searchIndex = await res.json();
      buildBm25Index();
    } catch (err) {
      console.error('Error loading search index:', err);
    }
  };

  loadIndex();

  const redirectToLucky = (query) => {
    const luckyUrl = `https://www.google.com/search?btnI=I&q=${encodeURIComponent(query)}`;
    window.location.href = luckyUrl;
  };

  const calculateBm25Scores = (queryTokens) => {
    if (!bm25Docs.length || !queryTokens.length) {
      return [];
    }

    const totalDocs = bm25Docs.length;

    return bm25Docs.map(doc => {
      let score = 0;

      queryTokens.forEach(token => {
        const tf = doc.termFrequency.get(token) || 0;
        if (tf === 0) return;

        const df = docFrequency.get(token) || 0;
        const idf = Math.log(1 + ((totalDocs - df + 0.5) / (df + 0.5)));
        const numerator = tf * (k1 + 1);
        const lengthRatio = averageDocLength ? (doc.length / averageDocLength) : 0;
        const denominator = tf + (k1 * (1 - b + (b * lengthRatio)));
        score += idf * (numerator / denominator);
      });

      return { ...doc, score };
    });
  };

  const performSearch = (source = 'text') => {
    const rawQuery = searchInput.value.trim();
    const query = rawQuery.toLowerCase();

    if (!rawQuery) {
      searchResultsContainer.innerHTML = '';
      if (source === 'voice') {
        setVoiceStatus('Please say what you want to search for.');
      } else {
        setVoiceStatus('');
      }
      return;
    }

    if (source === 'voice') {
      setVoiceStatus(`Searching the site for “${rawQuery}”...`, { persist: true });
    } else {
      setVoiceStatus('');
    }

    if (!bm25Docs.length) {
      if (source === 'voice') {
        setVoiceStatus('Voice search is still preparing our site index. Please try again in a moment.', { persist: true });
        return;
      }

      searchResultsContainer.innerHTML = '<p>Search index is still loading. Please try again shortly.</p>';
      return;
    }

    const queryTokens = tokenize(query);
    const scoredDocs = calculateBm25Scores(queryTokens)
      .filter(doc => doc.score > 0)
      .sort((a, b) => b.score - a.score);

    if (scoredDocs.length === 0) {
      if (source === 'voice') {
        setVoiceStatus('No on-site matches were found. Sending you to Google for a wider search...', { persist: true });
        redirectToLucky(rawQuery);
        return;
      }

      searchResultsContainer.innerHTML = '<p>No results found.</p>';
      return;
    }

    if (source === 'voice') {
      const querySlug = slugify(rawQuery);
      const exactMatch = querySlug
        ? scoredDocs.find(doc => slugify(doc.url) === querySlug)
        : null;
      const bestMatch = exactMatch || scoredDocs[0];

      if (bestMatch) {
        const readableTarget = bestMatch.url
          .replace(/\.html?$/, '')
          .replace(/[-_]+/g, ' ')
          .replace(/\b\w/g, char => char.toUpperCase());

        setVoiceStatus(`Opening the best match for “${rawQuery}”: ${readableTarget}.`, { persist: true });
        window.location.href = bestMatch.url;
        return;
      }
    }

    if (scoredDocs.length === 1) {
      window.location.href = scoredDocs[0].url;
      return;
    }

    setVoiceStatus('');
    displayResults(scoredDocs);
  };

  const displayResults = (results) => {
    if (results.length === 0) {
      searchResultsContainer.innerHTML = '<p>No results found.</p>';
      return;
    }

    const html = results.map(result => `
      <div class="result-item">
        <h3><a href="${result.url}">${result.url}</a></h3>
        <p>${result.content.substring(0, 150)}...</p>
      </div>
    `).join('');

    searchResultsContainer.innerHTML = html;
  };

  searchButton.addEventListener('click', () => performSearch('text'));
  searchInput.addEventListener('keyup', (event) => {
    if (event.key === 'Enter') {
      performSearch('text');
    }
  });

  const NativeRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

  if (NativeRecognition && voiceSearchButton) {
    const recognition = new NativeRecognition();
    recognition.continuous = false;
    recognition.lang = document.documentElement.lang || 'en-US';
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;

    const resetVoiceUi = () => {
      voiceSearchButton.classList.remove('listening');
      voiceSearchButton.removeAttribute('aria-busy');
    };

    voiceSearchButton.addEventListener('click', () => {
      try {
        setVoiceStatus('Listening…', { persist: true });
        voiceSearchButton.classList.add('listening');
        voiceSearchButton.setAttribute('aria-busy', 'true');
        recognition.start();
      } catch (err) {
        console.error('Speech recognition start error:', err);
        setVoiceStatus('Unable to start voice search. Please try again.', { persist: true });
        resetVoiceUi();
      }
    });

    recognition.onresult = (event) => {
      const transcript = (event.results[0][0]?.transcript || '').trim();
      if (!transcript) {
        setVoiceStatus('We didn’t catch that. Please try speaking again.', { persist: true });
        return;
      }

      searchInput.value = transcript;
      performSearch('voice');
    };

    recognition.onerror = (event) => {
      console.error('Speech recognition error:', event.error);
      let message = 'Voice search had a problem. Please try again.';
      if (event.error === 'not-allowed') {
        message = 'Microphone access was blocked. Please allow access and try again.';
      } else if (event.error === 'no-speech') {
        message = 'No speech detected. Please try again.';
      }
      setVoiceStatus(message, { persist: true });
    };

    recognition.onend = () => {
      resetVoiceUi();
    };

    recognition.onnomatch = () => {
      setVoiceStatus('I couldn’t understand that. Please try again.', { persist: true });
    };
  } else if (voiceSearchButton) {
    voiceSearchButton.style.display = 'none';
  }
});
